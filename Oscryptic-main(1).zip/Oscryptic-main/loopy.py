while true # start an infinite loop

do

echo "Hello" print "Hello"

sleep 1 wait for 1 second

done #end the loop